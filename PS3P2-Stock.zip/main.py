#input phase
PurchasePrice = float(input("Enter Purchase Price Per Share"))
StockPrice = float(input("Enter Stock Price"))
QuantityOfStock = float(input("Quantity Of Stock"))

#Process phase
StockPriceValue = StockPrice - PurchasePrice * QuantityOfStock 


#Output phase
print("StockPriceValue", StockPriceValue) 
