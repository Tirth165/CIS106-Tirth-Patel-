#input phase 
FirstExamScore = float(input("Enter First Exam Score"))
SecondExamScore = float(input("Enter Second Exam Score"))

#process phase 
total = FirstExamScore * .60 
total = SecondExamScore * .40 

#output phase 
print("Total Exam Score",total)
