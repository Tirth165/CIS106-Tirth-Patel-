#inputphase 

Firstname = input("Enter the first name")
NumberOfSteps = float(input("Number Of Steps"))

#Processphase
CaloriesBurned = .25 * NumberOfSteps 

#Outputphase
print("Person: ", Firstname ) 
print("CaloriesBurned: ", CaloriesBurned)