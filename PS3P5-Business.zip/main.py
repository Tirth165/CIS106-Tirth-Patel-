#Input phase 
FixedCosts = float(input("Determine Fixed Costs"))
PricePerUnit = float(input("Determine PricePerUnit"))
CostPerUnit = float(input("Determine Cost PerUnit")) 

#Process phase
Breakevenpoint = FixedCosts / PricePerUnit - CostPerUnit 

#Output phase 
print("Breakevenpoint: ", Breakevenpoint) 