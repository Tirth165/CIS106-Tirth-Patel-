#input phase 

Tip = float(input("Enter Tip Amount"))
TotalValue = float(input("Enter Total Value ")) 

#Process phase
Total = Tip + TotalValue

#Output phase
print("Total", Total ) 
